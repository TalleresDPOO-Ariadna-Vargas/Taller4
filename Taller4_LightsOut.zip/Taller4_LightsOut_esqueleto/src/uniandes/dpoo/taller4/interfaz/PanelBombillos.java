package uniandes.dpoo.taller4.interfaz;

import javax.swing.*;

import uniandes.dpoo.taller4.modelo.Tablero;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class PanelBombillos extends JPanel implements MouseListener {

	private Tablero tablero;
    private int tamanoCelda;
    private int filas;
    private int columnas;
    private ImageIcon imagenBombillo;
    private int ultima_fila;
    private int ultima_columna;
	public boolean verificarVictoria;
    

    public PanelBombillos(int size)
    {
    	this.tablero= new Tablero(size);
    	this.filas= tablero.darTablero().length;
    	this.columnas= tablero.darTablero()[0].length;
    	this.tamanoCelda = 50;
    	this.imagenBombillo =  new ImageIcon ("./data/luz.png");
    	
    	setPreferredSize(new Dimension(filas * tamanoCelda, columnas * tamanoCelda));
        addMouseListener(this);
    	
	}
    
    public void pintarCasillas (Graphics g)
    {
    	 
    	super.paintComponent(g);

        boolean[][] casillas = tablero.darTablero();
        
        for (int i = 0; i < filas; i++) 
        {
        	 for (int j = 0; j < columnas; j++)
        	 {
        		 if (casillas[i][j])
        		 {
        			 g.setColor(Color.YELLOW); // Fondo amarillo
                     g.fillRect(i * tamanoCelda, j * tamanoCelda, tamanoCelda, tamanoCelda);
                     if (imagenBombillo != null)
                     {
                    	 Image img = imagenBombillo.getImage();
                         g.drawImage(img, i * tamanoCelda, j * tamanoCelda, tamanoCelda, tamanoCelda, null); 
                     }
        		 }
        		 else
        		 {
        			 g.setColor(Color.BLACK); // Fondo negro
                     g.fillRect(i * tamanoCelda, j * tamanoCelda, tamanoCelda, tamanoCelda);
                     if (imagenBombillo != null)
                     {
                    	 Image img = imagenBombillo.getImage();
                         g.drawImage(img, i * tamanoCelda, j * tamanoCelda, tamanoCelda, tamanoCelda, null); 
                     }
                 
        		 }
        	 }
        }
        		
    }
    
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        pintarCasillas(g);
    }
    
    
    
    
    public void desordenarTablero(int dificultad) {
        tablero.desordenar(dificultad);
        repaint();
    }
    
    public void setTablero(int size)
    {
    	this.tablero= new Tablero(size);
    	this.filas= tablero.darTablero().length;
    	this.columnas= tablero.darTablero()[0].length;
    	this.tamanoCelda = 50;
    	this.tamanoCelda = Math.min(getWidth() / filas, getHeight() / columnas);
    	this.imagenBombillo =  new ImageIcon ("./data/luz.png");
    	
    	repaint();
    	
    }
    
    public int infoJugadas()
    {
    	return tablero.darJugadas();
    }
    
  
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
	private int[] convertirCoordenadasACasilla(int x, int y)
	{
		
		int ladoTablero = tablero.darTablero().length;
		int altoPanelTablero = getHeight();
		int anchoPanelTablero = getWidth();
		int altoCasilla = altoPanelTablero / ladoTablero;
		int anchoCasilla = anchoPanelTablero / ladoTablero;
		int fila = (int) (x / altoCasilla);
		int columna = (int) (y / anchoCasilla);
		return new int[] { fila, columna };
	}


	


	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) 
	{
		int click_x = e.getX();
	    int click_y = e.getY();
	    int[] casilla = convertirCoordenadasACasilla(click_x, click_y);
	    tablero.jugar(casilla[0], casilla[1]);
	    this.ultima_fila = casilla[0];
	    this.ultima_columna = casilla[1]; 
	    verificarVictoria();
	    repaint();
	    
	    
	    
	    
	}

	private boolean verificarVictoria() {
		
		return tablero.tableroIluminado();
		   
		 
	}
	
	public int puntajeJuego() {
		return tablero.calcularPuntaje();
	}

	public void reiniciar() {
		tablero.reiniciar();
		
	}
    
    
    
}

