package uniandes.dpoo.taller4.interfaz;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.util.Collection;

import uniandes.dpoo.taller4.modelo.RegistroTop10;
import uniandes.dpoo.taller4.modelo.Top10;


public class PanelTop10  extends JDialog{
	
	private JList<RegistroTop10> top10List;
	private DefaultListModel<RegistroTop10> listModel;
	
	public PanelTop10(Top10  top10) {
		setTitle("Top 10");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        
        listModel = new DefaultListModel<>();
        top10List = new JList<>(listModel);
        
        Collection<RegistroTop10> registros = top10.darRegistros();
        
        for (RegistroTop10 registro : registros) 
        {
            listModel.addElement(registro);
        }
        
        ;
        top10List.setCellRenderer(new RegistroTop10Renderer());
        JScrollPane scrollPane = new JScrollPane(top10List);

        add(scrollPane, BorderLayout.CENTER);
	}
	
	private class RegistroTop10Renderer extends DefaultListCellRenderer {
	    @Override
	    public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
	        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
	        RegistroTop10 registro = (RegistroTop10) value;
	        setText(registro.toString());

	        if (index < 3) {
	            setFont(getFont().deriveFont(Font.BOLD, 14f));
	            setForeground(Color.GREEN); 
	        } else if (index < 5) {
	            setFont(getFont().deriveFont(Font.BOLD, 14f));
	            setForeground(Color.BLUE); 
	        } else {
	            setForeground(Color.BLACK);
	        }

	        setBorder(new LineBorder(Color.BLACK));
	        setHorizontalAlignment(SwingConstants.CENTER);
	        setPreferredSize(new Dimension(400, 40));

	        return this;
	    }
	}

	

}
