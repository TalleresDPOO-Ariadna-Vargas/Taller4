package uniandes.dpoo.taller4.interfaz;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.text.*;
import java.util.Collection;

import javax.swing.*;
import javax.swing.border.*;

import uniandes.dpoo.taller4.modelo.RegistroTop10;
import uniandes.dpoo.taller4.modelo.Tablero;
import uniandes.dpoo.taller4.modelo.Top10;

public class lightsOutPanel extends JFrame
{
	private PanelBombillos panelBombillos;
	private JComboBox<Integer> tamanioComboBox;
	private JComboBox<Object> dificultadComboBox;
	private JLabel labelInfoJugadas;
	private String nombreJugador;
	private JPanel comboBoxPanelS;
	protected JLabel labelInfoJugador;

	
	
	
	public lightsOutPanel()
	{
		
		
		int defaultSize= 6;
		panelBombillos = new PanelBombillos(defaultSize);
		panelBombillos.desordenarTablero(5);
		pedirNombreJugador();
		
		
		JLabel labelTamanio = new JLabel("Tama�o: ");
		
		tamanioComboBox = new JComboBox<>();
		tamanioComboBox.addItem(6);
		tamanioComboBox.addItem(8);
		tamanioComboBox.addItem(10);
		tamanioComboBox.addItem(12);
		
		tamanioComboBox.addActionListener(new ActionListener()
		{

			
			public void actionPerformed(ActionEvent e) 
			{
				int nuevoTamanio = (int) tamanioComboBox.getSelectedItem();
				panelBombillos.setTablero(nuevoTamanio);
				panelBombillos.desordenarTablero(5);
			}
			
		});
		
		JLabel labelDificultad = new JLabel("Dificultad: ");
		
		dificultadComboBox = new JComboBox<>();
		dificultadComboBox.addItem("Facil");
		dificultadComboBox.addItem("Medio");
		dificultadComboBox.addItem("Dificil");
		
		dificultadComboBox.addActionListener(new ActionListener()
		{

			
			public void actionPerformed(ActionEvent e) 
			{
				String selectedDifficulty = (String) dificultadComboBox.getSelectedItem();
				int dificultad= 0;
                if (selectedDifficulty.equals("Facil")) {
                    dificultad = 5;
                } else if (selectedDifficulty.equals("Medio")) {
                	dificultad = 10;
                } else if (selectedDifficulty.equals("Dificil")) {
                	dificultad = 20;
                }
                panelBombillos.desordenarTablero(dificultad);
                panelBombillos.repaint();
            }
			
			
		});
		
		JLabel labelJugadas = new JLabel("Jugadas: ");
		labelInfoJugadas = new JLabel(Integer.toString(panelBombillos.infoJugadas()));
		labelJugadas.setHorizontalAlignment(JLabel.RIGHT);
        labelInfoJugadas.setHorizontalAlignment(JLabel.LEFT);
        
        JLabel labelNombre = new JLabel("Jugador: ");
        labelNombre.setHorizontalAlignment(JLabel.RIGHT);
        JLabel labelInfoJugador = new JLabel(nombreJugador);
        labelInfoJugador.setHorizontalAlignment(JLabel.LEFT);
		
		Top10 top10 = new Top10();
		top10.cargarRecords(new File("./data/top10.csv"));
		
		JButton top10Button = new JButton("TOP 10");
		top10Button.addActionListener(new ActionListener() {
			

			public void actionPerformed(ActionEvent e) {
            
            	JDialog top10Dialog = new PanelTop10(top10);
                top10Dialog.setTitle("Top 10");
                top10Dialog.setModal(true); 
                top10Dialog.pack();
                top10Dialog.setVisible(true);
            }
        });
		JPanel buttonPanel = new JPanel();
        buttonPanel.add(top10Button);
        
        JButton reiniciarButton = new JButton("Reiniciar");
        reiniciarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	panelBombillos.reiniciar();
            	panelBombillos.repaint();
            	labelInfoJugadas.setText("0");
            }
        });
		buttonPanel.add(reiniciarButton);
		
		JButton cambiarJugadorButton = new JButton("Cambiar Jugador");
		cambiarJugadorButton.addActionListener(new ActionListener()
			{
			

			public void actionPerformed(ActionEvent e) {
				
			pedirNombreJugador();
			labelInfoJugador.setText(nombreJugador); 
			comboBoxPanelS.revalidate();
			}
	});
		buttonPanel.add(cambiarJugadorButton);
		
		
		addWindowListener((WindowListener) new WindowAdapter() {
	        public void windowClosing(WindowEvent e) {
	            try {
					salvarTop10();
				} catch (FileNotFoundException | UnsupportedEncodingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	        }
	    });
		
		
		
		
		setLayout(new BorderLayout());
		JPanel comboBoxPanel = new JPanel();
        comboBoxPanel.add(labelTamanio);
        comboBoxPanel.add(tamanioComboBox);
        comboBoxPanel.add(labelDificultad);
        comboBoxPanel.add(dificultadComboBox);
        
        comboBoxPanelS = new JPanel();
        comboBoxPanelS.add(labelJugadas);
        comboBoxPanelS.add(labelInfoJugadas);
        comboBoxPanelS.add(labelNombre);
        comboBoxPanelS.add(labelInfoJugador);
        
        comboBoxPanelS.setLayout(new FlowLayout(FlowLayout.LEFT));
        

		
		add(comboBoxPanel, BorderLayout.NORTH);
        add(panelBombillos, BorderLayout.CENTER);
        add(comboBoxPanelS, BorderLayout.SOUTH);
        add(buttonPanel, BorderLayout.WEST);
		
        
        
	}
	
	private void pedirNombreJugador() {
	    String nombre = JOptionPane.showInputDialog(this, "Por favor, ingrese su nombre:", "Ingrese su nombre", JOptionPane.PLAIN_MESSAGE);
	    if (nombre != null && !nombre.isEmpty()) {
	        nombreJugador = nombre;
	    }
	}
	
	public void informarVictoria() {
		if (panelBombillos.verificarVictoria == true)
       {
	
			int puntaje = panelBombillos.puntajeJuego();
			String mensaje = "Has ganado! Puntaje: " + puntaje;
            JOptionPane.showMessageDialog(this, mensaje, "Victoria", JOptionPane.INFORMATION_MESSAGE);
            
           
    }}
	
	private void salvarTop10() throws FileNotFoundException, UnsupportedEncodingException {
		int puntaje = panelBombillos.puntajeJuego();
		Top10 top10 = new Top10();
        top10.cargarRecords(new File("./data/top10.csv"));
         if (top10.esTop10(puntaje))
         {
           top10.agregarRegistro(nombreJugador, puntaje);
         }
         top10.salvarRecords(new File("./data/top10.csv"));
	}

	
	
	public static void main( String[] pArgs )
	{
		try
		{
			// Unifica la interfaz para Mac y para Windows.
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());

	        
	        lightsOutPanel interfaz = new lightsOutPanel();
	        
	        interfaz.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        interfaz.pack();
	        interfaz.setVisible(true);
		}
		catch( Exception e )
		{
			e.printStackTrace( );
		}
	}




	
}